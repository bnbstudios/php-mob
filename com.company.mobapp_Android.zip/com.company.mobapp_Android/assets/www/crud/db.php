<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("127.0.0.1","root","","mobile_db") or die ("could not connect database");
?>